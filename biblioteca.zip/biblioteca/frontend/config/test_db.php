return [
  'dsn' => getenv('DB_DSN'),
  'username' => getenv('DB_USER'),
  'password' => getenv('DB_PASS'),
  'charset' => 'utf8',
];
