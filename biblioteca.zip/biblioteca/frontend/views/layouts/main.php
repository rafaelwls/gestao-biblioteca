<?php
/* frontend/views/layouts/main.php */

use yii\helpers\Html;
use frontend\assets\AppAsset;

AppAsset::register($this);
?>
<?php $this->beginPage() ?>
<!DOCTYPE html>
<html lang="<?= Yii::$app->language ?>">

<head>
    <meta charset="<?= Yii::$app->charset ?>">
    <meta name="viewport" content="width=device-width,initial-scale=1">
    <?php $this->registerCsrfMetaTags() ?>
    <title><?= Html::encode($this->title) ?></title>
    <?php $this->head() ?>
    <!-- Layout CSS estático -->
    <style>

    </style>
</head>

<script>
    document.addEventListener('DOMContentLoaded', function () {
        const sidebar = document.getElementById('sidebar');
        const btnSidebar = document.getElementById('sidebarToggle');
        const btnTheme = document.getElementById('themeToggle');
        const app = document.getElementById('app');

        // Inicializa tema  
        const saved = localStorage.getItem('theme') || 'light';
        app.setAttribute('data-theme', saved);
        btnTheme.textContent = saved === 'light' ? '🌙' : '☀️';

        // Toggle sidebar
        btnSidebar.addEventListener('click', () => {
            sidebar.classList.toggle('hidden-sidebar');
        });

        // Toggle theme
        btnTheme.addEventListener('click', () => {
            const current = app.getAttribute('data-theme');
            const next = current === 'light' ? 'dark' : 'light';
            app.setAttribute('data-theme', next);
            localStorage.setItem('theme', next);
            btnTheme.textContent = next === 'light' ? '🌙' : '☀️';
        });
    }); 
</script>

<body id="app" data-theme="light">
    <?php $this->beginBody() ?>

    <!-- Sidebar -->
    <aside id="sidebar">
        <?= \frontend\widgets\SidebarWidget::widget() ?>
    </aside>

    <!-- Conteúdo principal --> 
    <div class="main-wrapper header-title">
        <header>
            <?= \frontend\widgets\HeaderWidget::widget() ?> 
            <button id="sidebarToggle" class="ml-4">☰</button>
            <button id="themeToggle" class="ml-2">🌙</button>
        </header>
        <main>
            <?= $content ?>
        </main>
    </div> 

    <?php $this->endBody() ?>
</body>

</html>
<?php $this->endPage() ?>