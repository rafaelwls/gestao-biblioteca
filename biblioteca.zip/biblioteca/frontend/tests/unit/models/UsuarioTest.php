<?php
namespace tests\unit\models;

use frontend\models\Usuario;
use PHPUnit\Framework\TestCase;

class UsuarioTest extends TestCase
{
  public function testGetFullName()
  {
    $user = new Usuario([
      'nome'      => 'Maria',
      'sobrenome' => 'Silva',
    ]);
    $this->assertEquals('Maria Silva', $user->getFullName());
  }
}
