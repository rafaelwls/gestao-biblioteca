<?php
namespace tests\unit\models;

use frontend\models\Emprestimo;
use PHPUnit\Framework\TestCase;

class EmprestimoTest extends TestCase
{
  public function testCalculateMultaNoAtraso()
  {
    $e = new Emprestimo([
      'data_devolucao_prevista' => '2025-06-10',
      'data_devolucao_real'     => '2025-06-09',
    ]);
    $this->assertEquals(0.0, $e->calculateMulta());
  }

  public function testCalculateMultaComAtraso()
  {
    $e = new Emprestimo([
      'data_devolucao_prevista' => '2025-06-10',
      'data_devolucao_real'     => '2025-06-12',
    ]);
    // 2 dias de atraso × R$2,50 = R$5,00
    $this->assertEquals(5.00, $e->calculateMulta());
  }
}
