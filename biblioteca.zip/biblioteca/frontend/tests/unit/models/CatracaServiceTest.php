<?php
namespace tests\unit\services;

use frontend\services\CatracaService;
use PHPUnit\Framework\TestCase;

class CatracaServiceTest extends TestCase
{
  public function testRegistrarEntrada()
  {
    $service = new CatracaService();
    $result  = $service->registrar('uuid-usuario', 'ENTRADA');
    $this->assertArrayHasKey('usuario_id', $result);
    $this->assertEquals('ENTRADA', $result['tipo']);
    $this->assertMatchesRegularExpression(
      '/\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2}/',
      $result['timestamp']
    );
  }
}
