<?php
namespace tests\unit\models;

use frontend\models\Exemplar;
use PHPUnit\Framework\TestCase;
use yii\db\Expression;

class ExemplarTest extends TestCase
{
  public function testRemover()
  {
    $ex = new Exemplar([
      'status'       => 'disponivel',
      'estado'       => 'novo',
      'codigo_barras'=> '12345',
    ]);
    $ex->remover('DANIFICADO');
    $this->assertEquals('removido', $ex->status);
    $this->assertEquals('DANIFICADO', $ex->motivo_remocao);
    $this->assertInstanceOf(Expression::class, $ex->data_remocao);
  }
}
