<?php
return [
  'dsn'      => 'pgsql:host=127.0.0.1;port=5432;dbname=biblioteca',
  'username' => 'postgres',
  'password' => '123',
  'charset'  => 'utf8',
];
