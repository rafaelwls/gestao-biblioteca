Comparación
===========

Las siguiente tabla compara las diferencias entre las plantillas de proyecto avanzada y básica:


| Característica  |  Básica  |  Avanzada |
|---|:---:|:---:|
| Estructura del proyecto | ✓ | ✓ |
| Controlador site | ✓ | ✓ |
| Usuario login/logout | ✓ | ✓ |
| Formularios | ✓ | ✓ |
| Conexión DB | ✓ | ✓ |
| Comandos de consola | ✓ | ✓ |
| Asset bundle | ✓ | ✓ |
| Tests con Codeception | ✓ | ✓ |
| Twitter Bootstrap | ✓ | ✓ |
| Front- y back-end apps |    | ✓ |
| Modelo User listo para usar |    | ✓ |
| Registro de usuarios y restablecimiento de contraseña |     | ✓ |
